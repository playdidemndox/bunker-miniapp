# ☢️ Бункер: Поколение Альфа - Многопользовательский Telegram Mini App

<p align="center">
  <img src="https://img.shields.io/badge/Telegram-Mini%20App-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white" alt="Telegram Mini App">
  <img src="https://img.shields.io/badge/Socket.IO-4.7-010101?style=for-the-badge&logo=socket.io&logoColor=white" alt="Socket.IO">
  <img src="https://img.shields.io/badge/Node.js-18+-339933?style=for-the-badge&logo=node.js&logoColor=white" alt="Node.js 18+">
</p>

<p align="center">
  <strong>Многопользовательская дискуссионная карточная игра с апокалиптическим сюжетом</strong>
</p>

---

## 🎮 О игре

**"Бункер: Поколение Альфа"** — это многопользовательская дискуссионная карточная игра, где игрокам предстоит выжить в условиях глобальной катастрофы. 

### Ключевые особенности:
- 🌐 **Многопользовательский режим** — играйте с друзьями с разных устройств
- 🏠 **Комнаты** — создавайте комнаты и подключайтесь по коду
- ⚡ **Real-time синхронизация** — мгновенные обновления через Socket.IO
- 🎯 **Два режима игры** — Базовый и История выживания
- 👥 **4-10 игроков** в одной игре
- 🃏 **300+ уникальных карт**

---

## 📁 Структура проекта

```
bunker-game/
├── public/                 # Статические файлы Mini App
│   ├── index.html         # Главная страница
│   ├── style.css          # Стили
│   ├── script.js          # Клиентская логика
│   └── cards.json         # Данные карт
├── server.js              # Node.js сервер + Socket.IO
├── package.json           # Зависимости
├── .env.example           # Пример конфигурации
└── README.md              # Этот файл
```

---

## 🚀 Быстрый старт

### 1. Установка

```bash
# Клонируйте репозиторий
git clone <repository-url>
cd bunker-game

# Установите зависимости
npm install

# Создайте файл конфигурации
cp .env.example .env
```

### 2. Настройка переменных окружения

Отредактируйте `.env`:

```env
BOT_TOKEN=your_telegram_bot_token
WEBHOOK_URL=https://your-domain.com/webhook
MINI_APP_URL=https://your-domain.com
PORT=3000
```

### 3. Запуск

```bash
# Локальная разработка
npm run dev

# Продакшн
npm start
```

---

## 🌐 Развёртывание на Railway

### Шаг 1: Подготовка

1. Создайте аккаунт на [Railway](https://railway.app)
2. Свяжите с GitHub репозиторием

### Шаг 2: Деплой

```bash
# Установите Railway CLI
npm install -g @railway/cli

# Логин
railway login

# Инициализация
railway init

# Деплой
railway up
```

### Шаг 3: Настройка переменных окружения

В панели Railway добавьте:

```
BOT_TOKEN=8505568581:AAFqPR_VNPVFp4FK7-JZm_IRinQ2NjR3y-M
WEBHOOK_URL=https://your-app.up.railway.app/webhook
MINI_APP_URL=https://your-app.up.railway.app
```

### Шаг 4: Настройка webhook

```bash
curl https://your-app.up.railway.app/setup-webhook?url=https://your-app.up.railway.app/webhook
```

---

## 🤖 Настройка Telegram Bot

### 1. Создание бота

1. Напишите [@BotFather](https://t.me/BotFather)
2. Используйте `/newbot` и следуйте инструкциям
3. Сохраните токен

### 2. Настройка Mini App

В [@BotFather](https://t.me/BotFather):

```
/mybots → Выберите бота → Bot Settings → Menu Button → Configure menu button
```

- **Button text**: `Играть`
- **URL**: `https://your-app.up.railway.app`

### 3. Настройка Webhook

```
/setinline
```

---

## 🎯 Как играть

### Создание игры:
1. Нажмите "Создать комнату"
2. Выберите режим и количество игроков
3. Поделитесь кодом комнаты с друзьями

### Присоединение:
1. Нажмите "Присоединиться"
2. Введите 6-значный код комнаты
3. Ожидайте начала игры

### Игровой процесс:
1. **Исследование** — откройте карты бункера и угрозы
2. **Открытие карт** — каждый игрок открывает по одной карте
3. **Голосование** — выберите, кого изгнать
4. **Победа** — попадите в бункер после 5 раундов!

---

## 📋 Команды бота

| Команда | Описание |
|---------|----------|
| `/start` | Начать работу с ботом |
| `/create` | Создать новую комнату |
| `/join КОД` | Присоединиться к комнате |
| `/help` | Справка по командам |

---

## 🔧 API Endpoints

### HTTP

| Endpoint | Метод | Описание |
|----------|-------|----------|
| `/` | GET | Mini App |
| `/health` | GET | Проверка работоспособности |
| `/webhook` | POST | Telegram webhook |
| `/api/room/:code` | GET | Информация о комнате |

### Socket.IO Events

#### Client → Server

| Event | Данные | Описание |
|-------|--------|----------|
| `create-room` | `{playerId, playerName, maxPlayers, gameMode}` | Создать комнату |
| `join-room` | `{roomCode, playerId, playerName}` | Присоединиться |
| `player-ready` | `{isReady}` | Готовность |
| `start-game` | `{}` | Начать игру |
| `explore-bunker` | `{}` | Исследовать бункер |
| `reveal-card` | `{cardType}` | Открыть карту |
| `cast-vote` | `{targetId}` | Проголосовать |
| `continue-after-vote` | `{}` | Продолжить |

#### Server → Client

| Event | Данные | Описание |
|-------|--------|----------|
| `room-update` | `{players, status}` | Обновление комнаты |
| `player-joined` | `{player}` | Игрок присоединился |
| `game-started` | `{gameState, myCards}` | Игра началась |
| `game-update` | `{gameState, players}` | Обновление игры |
| `voting-progress` | `{votedCount, totalCount}` | Прогресс голосования |

---

## 🛠️ Технологии

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Node.js, Express
- **Real-time**: Socket.IO
- **API**: Telegram Bot API, Telegram WebApp API

---

## 📱 Совместимость

- ✅ iOS (Safari, Chrome)
- ✅ Android (Chrome, Telegram WebView)
- ✅ Desktop (Chrome, Firefox, Safari)

---

## 🔒 Безопасность

- Токен бота в переменных окружения
- Валидация входящих данных
- Автоматическая очистка неактивных комнат

---

## 📝 Лицензия

MIT License

---

<p align="center">
  <strong>☢️ Удачи в выживании! ☢️</strong>
</p>
